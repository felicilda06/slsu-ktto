-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 21, 2022 at 04:36 PM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.0.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `slsu_kttodb`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_accounts`
--

CREATE TABLE `tbl_accounts` (
  `id` int(11) NOT NULL,
  `studentId` varchar(50) DEFAULT NULL,
  `email` varchar(50) NOT NULL,
  `name` varchar(75) NOT NULL,
  `password` varchar(255) NOT NULL,
  `usertype` varchar(20) NOT NULL,
  `technology_type` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_accounts`
--

INSERT INTO `tbl_accounts` (`id`, `studentId`, `email`, `name`, `password`, `usertype`, `technology_type`) VALUES
(22, '', 'juviecano10@gmail.com', 'Juvie Cano', 'dc107fd4d7a7cb25c3d39bcdbcf1b1f94086eccb', 'patent drafter', 'chemical'),
(26, '1610131', 'felicildarichard06@gmail.com', 'Richard', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', 'maker', ''),
(27, '1610131-1', 'yen@gmail.com', 'Charlane', '720766642bbc5bdda2c7e4118ded65e0d8ce9d19', 'maker', ''),
(28, '', 'lindell@gmail.com', 'Lindell', 'cce7aa8d4b90d8032bbf21a475a17ee00ed3548f', 'patent drafter', 'non-chemical');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_codes`
--

CREATE TABLE `tbl_codes` (
  `id` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `code` int(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_codes`
--

INSERT INTO `tbl_codes` (`id`, `email`, `code`) VALUES
(15, 'juviecano10@gmail.com', 9061);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_comments`
--

CREATE TABLE `tbl_comments` (
  `id` int(11) NOT NULL,
  `comments` varchar(10000) NOT NULL,
  `maker_id` int(11) NOT NULL,
  `patent_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_documents`
--

CREATE TABLE `tbl_documents` (
  `id` int(11) NOT NULL,
  `formality_result` varchar(255) NOT NULL,
  `acknowledgement_receipt` varchar(255) NOT NULL,
  `notice_of_withdrawal` varchar(255) NOT NULL,
  `notice_of_publication` varchar(255) NOT NULL,
  `certification` varchar(255) NOT NULL,
  `log_submission_status` varchar(255) NOT NULL,
  `response` varchar(255) NOT NULL,
  `patent_id` int(11) NOT NULL,
  `maker_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_document_types`
--

CREATE TABLE `tbl_document_types` (
  `id` int(11) NOT NULL,
  `label` varchar(100) NOT NULL,
  `value` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_document_types`
--

INSERT INTO `tbl_document_types` (`id`, `label`, `value`) VALUES
(1, 'Drafted Documents', 'drafted documents'),
(2, 'Formality Exam Result', 'formality exam result');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_studies`
--

CREATE TABLE `tbl_studies` (
  `id` int(11) NOT NULL,
  `title` varchar(75) NOT NULL,
  `proponent` varchar(75) NOT NULL,
  `technology_type` varchar(25) NOT NULL,
  `contact_information` varchar(11) NOT NULL,
  `file` varchar(100) NOT NULL,
  `authors` varchar(255) NOT NULL,
  `created_at` varchar(50) NOT NULL,
  `status` varchar(15) NOT NULL,
  `bg_color` varchar(25) NOT NULL,
  `is_new_uploaded` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_studies`
--

INSERT INTO `tbl_studies` (`id`, `title`, `proponent`, `technology_type`, `contact_information`, `file`, `authors`, `created_at`, `status`, `bg_color`, `is_new_uploaded`) VALUES
(18, 'Test', 'test', 'chemical', '09456456456', 'Screenshot (1).png', 'felicildarichard06@gmail.com', 'November 19, 2022', 'Pending', 'e3e5e6', 1),
(19, 'Biology', 'test', 'non-chemical', '08907897686', 'pexels-mike-b-170811 (2).jpg', 'yen@gmail.com', 'November 19, 2022', 'Pending', 'e3e5e6', 0),
(20, 'Test 2', 'test 2', 'non-chemical', '08978768678', 'sample.pdf', 'felicildarichard06@gmail.com', 'November 19, 2022', 'Pending', 'e3e5e6', 0),
(21, 'Test 3', 'test 3', 'chemical', '09675675675', 'sample.pdf', 'felicildarichard06@gmail.com', 'November 19, 2022', 'Pending', 'e3e5e6', 1),
(22, 'Test 5', 'test 5', 'non-chemical', '09786875675', 'pexels-mike-b-170811 (2).jpg', 'felicildarichard06@gmail.com', 'November 19, 2022', 'Pending', 'e3e5e6', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_accounts`
--
ALTER TABLE `tbl_accounts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_codes`
--
ALTER TABLE `tbl_codes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_comments`
--
ALTER TABLE `tbl_comments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_documents`
--
ALTER TABLE `tbl_documents`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_document_types`
--
ALTER TABLE `tbl_document_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_studies`
--
ALTER TABLE `tbl_studies`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_accounts`
--
ALTER TABLE `tbl_accounts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `tbl_codes`
--
ALTER TABLE `tbl_codes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `tbl_comments`
--
ALTER TABLE `tbl_comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbl_documents`
--
ALTER TABLE `tbl_documents`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `tbl_document_types`
--
ALTER TABLE `tbl_document_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_studies`
--
ALTER TABLE `tbl_studies`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
