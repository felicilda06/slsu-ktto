-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 05, 2022 at 08:14 PM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.0.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `slsu_kttodb`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_accounts`
--

CREATE TABLE `tbl_accounts` (
  `id` int(11) NOT NULL,
  `studentId` varchar(50) DEFAULT NULL,
  `email` varchar(50) NOT NULL,
  `name` varchar(75) NOT NULL,
  `password` varchar(255) NOT NULL,
  `usertype` varchar(20) NOT NULL,
  `technology_type` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_accounts`
--

INSERT INTO `tbl_accounts` (`id`, `studentId`, `email`, `name`, `password`, `usertype`, `technology_type`) VALUES
(22, '', 'juviecano10@gmail.com', 'Juvie Cano', 'dc107fd4d7a7cb25c3d39bcdbcf1b1f94086eccb', 'patent drafter', 'chemical'),
(26, '1610131', 'felicildarichard06@gmail.com', 'Richard', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', 'maker', ''),
(28, '', 'lindell@gmail.com', 'Lindell', 'cce7aa8d4b90d8032bbf21a475a17ee00ed3548f', 'patent drafter', 'non-chemical'),
(29, '', 'admin@gmail.com', 'Admin', 'd033e22ae348aeb5660fc2140aec35850c4da997', 'admin', ''),
(30, '1610137-2', 'yen@gmail.com', 'Charlene', '720766642bbc5bdda2c7e4118ded65e0d8ce9d19', 'maker', '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_codes`
--

CREATE TABLE `tbl_codes` (
  `id` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `code` int(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_codes`
--

INSERT INTO `tbl_codes` (`id`, `email`, `code`) VALUES
(15, 'juviecano10@gmail.com', 9061);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_comments`
--

CREATE TABLE `tbl_comments` (
  `id` int(11) NOT NULL,
  `comments` varchar(10000) NOT NULL,
  `maker_id` int(11) NOT NULL,
  `patent_id` int(11) NOT NULL,
  `sender` int(11) NOT NULL,
  `receiver` int(11) NOT NULL,
  `sender_name` varchar(75) NOT NULL,
  `read` tinyint(1) NOT NULL,
  `created_at` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_comments`
--

INSERT INTO `tbl_comments` (`id`, `comments`, `maker_id`, `patent_id`, `sender`, `receiver`, `sender_name`, `read`, `created_at`) VALUES
(31, 'This study is now submitted to IPOPHIL.', 26, 22, 22, 26, 'Juvie Cano', 0, 'December 4, 2022 08:50:21'),
(32, 'Way ayo imong study', 27, 22, 22, 26, 'Juvie Cano', 0, 'December 4, 2022 08:52:27'),
(41, 'thank you for the updates', 26, 22, 26, 22, 'Richard', 0, 'December 6, 2022 01:49:53'),
(45, 'Please double check your grammar', 29, 28, 28, 30, 'Lindell', 0, 'December 6, 2022 02:07:33');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_documents`
--

CREATE TABLE `tbl_documents` (
  `id` int(11) NOT NULL,
  `formality_result` varchar(255) NOT NULL,
  `acknowledgement_receipt` varchar(255) NOT NULL,
  `notice_of_withdrawal` varchar(255) NOT NULL,
  `notice_of_publication` varchar(255) NOT NULL,
  `certification` varchar(255) NOT NULL,
  `log_submission_status` varchar(255) NOT NULL,
  `response` varchar(255) NOT NULL,
  `patent_id` int(11) NOT NULL,
  `maker_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_documents`
--

INSERT INTO `tbl_documents` (`id`, `formality_result`, `acknowledgement_receipt`, `notice_of_withdrawal`, `notice_of_publication`, `certification`, `log_submission_status`, `response`, `patent_id`, `maker_id`) VALUES
(23, 'formality_result_26_sample (1).pdf', '', '', '', '', '', '', 22, 26);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_document_types`
--

CREATE TABLE `tbl_document_types` (
  `id` int(11) NOT NULL,
  `label` varchar(100) NOT NULL,
  `value` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_document_types`
--

INSERT INTO `tbl_document_types` (`id`, `label`, `value`) VALUES
(1, 'Drafted Documents', 'drafted documents'),
(2, 'Formality Exam Result', 'formality exam result');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_log_submission`
--

CREATE TABLE `tbl_log_submission` (
  `id` int(11) NOT NULL,
  `application_no` varchar(50) NOT NULL,
  `title` varchar(75) NOT NULL,
  `creator` varchar(75) NOT NULL,
  `ip_type` varchar(10) NOT NULL,
  `college` varchar(75) NOT NULL,
  `dragon_pay` varchar(75) NOT NULL,
  `application_date` varchar(50) NOT NULL,
  `agent` varchar(50) NOT NULL,
  `drafter` varchar(75) NOT NULL,
  `document_where_about` varchar(75) NOT NULL,
  `publication_date` varchar(50) NOT NULL,
  `publication_vol` varchar(10) NOT NULL,
  `publication_no` varchar(10) NOT NULL,
  `registration_date` varchar(50) NOT NULL,
  `registration_date_vol` varchar(10) NOT NULL,
  `registration_date_no` varchar(10) NOT NULL,
  `examiner` varchar(50) NOT NULL,
  `status` varchar(100) NOT NULL,
  `remark_1` varchar(100) NOT NULL,
  `remark_2` varchar(100) NOT NULL,
  `office_remark` varchar(100) NOT NULL,
  `action_step_1` varchar(75) NOT NULL,
  `action_step_2` varchar(75) NOT NULL,
  `certificate_office` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_log_submission`
--

INSERT INTO `tbl_log_submission` (`id`, `application_no`, `title`, `creator`, `ip_type`, `college`, `dragon_pay`, `application_date`, `agent`, `drafter`, `document_where_about`, `publication_date`, `publication_vol`, `publication_no`, `registration_date`, `registration_date_vol`, `registration_date_no`, `examiner`, `status`, `remark_1`, `remark_2`, `office_remark`, `action_step_1`, `action_step_2`, `certificate_office`) VALUES
(27, '1601231-1', 'Transformer: Rise of the Beast', 'Richard Poon', '', 'SLSU', '', '', '', '', '', '', '', '', '', '', '', '', 'Under Formality Examination', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_studies`
--

CREATE TABLE `tbl_studies` (
  `id` int(11) NOT NULL,
  `title` varchar(75) NOT NULL,
  `proponent` varchar(75) NOT NULL,
  `technology_type` varchar(25) NOT NULL,
  `contact_information` varchar(11) NOT NULL,
  `file` varchar(100) NOT NULL,
  `authors` varchar(255) NOT NULL,
  `created_at` varchar(50) NOT NULL,
  `status` varchar(15) NOT NULL,
  `bg_color` varchar(25) NOT NULL,
  `is_new_uploaded` tinyint(1) NOT NULL,
  `userId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_studies`
--

INSERT INTO `tbl_studies` (`id`, `title`, `proponent`, `technology_type`, `contact_information`, `file`, `authors`, `created_at`, `status`, `bg_color`, `is_new_uploaded`, `userId`) VALUES
(26, 'Transformer: Rise of the Beast', 'test1', 'chemical', '09789768678', 'file-sample_100kB (1).doc', 'felicildarichard06@gmail.com', 'December 04, 2022', 'Accept', 'a5ffc5', 1, 26),
(27, 'Troll', 'test', 'chemical', '09789789789', 'Layout1 (5).docx', 'felicildarichard06@gmail.com', 'December 04, 2022', 'Decline', 'fbafa3', 0, 26),
(29, 'John Wick', 'test 3', 'non-chemical', '09987897897', 'Screenshot (6).png', 'yen@gmail.com', 'December 06, 2022', 'Decline', 'fbafa3', 0, 30);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_accounts`
--
ALTER TABLE `tbl_accounts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_codes`
--
ALTER TABLE `tbl_codes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_comments`
--
ALTER TABLE `tbl_comments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_documents`
--
ALTER TABLE `tbl_documents`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_document_types`
--
ALTER TABLE `tbl_document_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_log_submission`
--
ALTER TABLE `tbl_log_submission`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_studies`
--
ALTER TABLE `tbl_studies`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_accounts`
--
ALTER TABLE `tbl_accounts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `tbl_codes`
--
ALTER TABLE `tbl_codes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `tbl_comments`
--
ALTER TABLE `tbl_comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT for table `tbl_documents`
--
ALTER TABLE `tbl_documents`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `tbl_document_types`
--
ALTER TABLE `tbl_document_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_log_submission`
--
ALTER TABLE `tbl_log_submission`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `tbl_studies`
--
ALTER TABLE `tbl_studies`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
