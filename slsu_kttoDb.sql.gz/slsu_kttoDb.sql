-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 01, 2023 at 11:15 AM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.0.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `slsu_kttodb`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_accounts`
--

CREATE TABLE `tbl_accounts` (
  `id` int(11) NOT NULL,
  `studentId` varchar(50) DEFAULT NULL,
  `email` varchar(50) NOT NULL,
  `name` varchar(75) NOT NULL,
  `password` varchar(255) NOT NULL,
  `usertype` varchar(20) NOT NULL,
  `technology_type` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_accounts`
--

INSERT INTO `tbl_accounts` (`id`, `studentId`, `email`, `name`, `password`, `usertype`, `technology_type`) VALUES
(22, '161013101', 'juviecano10@gmail.com', 'Juvie Cano', 'dc107fd4d7a7cb25c3d39bcdbcf1b1f94086eccb', 'patent drafter', 'chemical'),
(29, '', 'admin@gmail.com', 'IPOPHIL', 'd033e22ae348aeb5660fc2140aec35850c4da997', 'admin', ''),
(32, '1222323', 'julie@gmail.com', 'Julie Abrea', '8d32267b6b4884cf35adeaccde2b6857ae11aace', 'maker', ''),
(37, '12345', 'itso_clerk@gmail.com', 'Clerk', 'f38de2358e07b0c3d99164b3494ce57bff75ee70', 'clerk', '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_codes`
--

CREATE TABLE `tbl_codes` (
  `id` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `code` int(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_codes`
--

INSERT INTO `tbl_codes` (`id`, `email`, `code`) VALUES
(17, 'juviecano10@gmail.com', 9473);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_college`
--

CREATE TABLE `tbl_college` (
  `id` int(11) NOT NULL,
  `college` varchar(255) NOT NULL,
  `userId` int(11) NOT NULL,
  `default_item` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_college`
--

INSERT INTO `tbl_college` (`id`, `college`, `userId`, `default_item`) VALUES
(1, 'CCSIT', 0, 1),
(2, 'COE', 0, 1),
(3, 'CAFES', 0, 1),
(4, 'IAS', 0, 1),
(5, 'CHTM', 0, 1),
(6, 'COT', 0, 1),
(7, 'CAALS', 0, 1),
(8, 'GIS', 0, 1),
(10, 'New', 31, 0),
(11, 'San Juan Campus', 32, 0),
(12, 'Maasin SLSU', 32, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_comments`
--

CREATE TABLE `tbl_comments` (
  `id` int(11) NOT NULL,
  `comments` varchar(10000) NOT NULL,
  `maker_id` int(11) NOT NULL,
  `patent_id` int(11) NOT NULL,
  `sender` int(11) NOT NULL,
  `receiver` int(11) NOT NULL,
  `sender_name` varchar(75) NOT NULL,
  `read` tinyint(1) NOT NULL,
  `created_at` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_comments`
--

INSERT INTO `tbl_comments` (`id`, `comments`, `maker_id`, `patent_id`, `sender`, `receiver`, `sender_name`, `read`, `created_at`) VALUES
(156, 'Juvie Cano uploaded a formality result.', 61, 22, 22, 61, 'Juvie Cano', 0, 'February 18, 2023 10:49:01'),
(157, 'Please rewrite your study', 62, 22, 22, 31, 'Juvie Cano', 0, 'February 25, 2023 05:24:48'),
(158, 'Still an issue', 62, 22, 22, 31, 'Juvie Cano', 0, 'February 25, 2023 05:41:44');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_documents`
--

CREATE TABLE `tbl_documents` (
  `id` int(11) NOT NULL,
  `formality_result` varchar(255) NOT NULL,
  `acknowledgement_receipt` varchar(255) NOT NULL,
  `notice_of_withdrawal` varchar(255) NOT NULL,
  `notice_of_publication` varchar(255) NOT NULL,
  `certification` varchar(255) NOT NULL,
  `log_submission_status` varchar(255) NOT NULL,
  `response` varchar(255) NOT NULL,
  `drafted_documents` varchar(255) NOT NULL,
  `patent_id` int(11) NOT NULL,
  `maker_id` int(11) NOT NULL,
  `study_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_documents`
--

INSERT INTO `tbl_documents` (`id`, `formality_result`, `acknowledgement_receipt`, `notice_of_withdrawal`, `notice_of_publication`, `certification`, `log_submission_status`, `response`, `drafted_documents`, `patent_id`, `maker_id`, `study_id`) VALUES
(55, 'formality_result_61_20210224_172722-Formality-Examination-Report-Presence-of-Formalin-in-Fish.pdf', '', '', '', '', '', '', '', 22, 61, 61);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_document_types`
--

CREATE TABLE `tbl_document_types` (
  `id` int(11) NOT NULL,
  `label` varchar(100) NOT NULL,
  `value` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_log_submission`
--

CREATE TABLE `tbl_log_submission` (
  `id` int(11) NOT NULL,
  `application_no` varchar(50) NOT NULL,
  `title` varchar(75) NOT NULL,
  `creator` varchar(75) NOT NULL,
  `ip_type` varchar(10) NOT NULL,
  `college` varchar(75) NOT NULL,
  `dragon_pay` varchar(75) NOT NULL,
  `application_date` varchar(50) NOT NULL,
  `agent` varchar(50) NOT NULL,
  `drafter` varchar(75) NOT NULL,
  `document_where_about` varchar(75) NOT NULL,
  `publication_date` varchar(50) NOT NULL,
  `publication_vol` varchar(10) NOT NULL,
  `publication_no` varchar(10) NOT NULL,
  `registration_date` varchar(50) NOT NULL,
  `registration_date_vol` varchar(10) NOT NULL,
  `registration_date_no` varchar(10) NOT NULL,
  `examiner` varchar(50) NOT NULL,
  `status` varchar(100) NOT NULL,
  `expiration_date` varchar(75) NOT NULL,
  `remark_1` varchar(100) NOT NULL,
  `remark_2` varchar(100) NOT NULL,
  `office_remark` varchar(100) NOT NULL,
  `action_step_1` varchar(75) NOT NULL,
  `action_step_2` varchar(75) NOT NULL,
  `certificate_office` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_log_submission`
--

INSERT INTO `tbl_log_submission` (`id`, `application_no`, `title`, `creator`, `ip_type`, `college`, `dragon_pay`, `application_date`, `agent`, `drafter`, `document_where_about`, `publication_date`, `publication_vol`, `publication_no`, `registration_date`, `registration_date_vol`, `registration_date_no`, `examiner`, `status`, `expiration_date`, `remark_1`, `remark_2`, `office_remark`, `action_step_1`, `action_step_2`, `certificate_office`) VALUES
(43, '', 'Chap1', '', '', 'CTE', '', 'February 28, 2023', '', '', '', 'March 02, 2023', '', '', 'February 25, 2023', '', '', '', 'Withdrawn', 'February 28, 2023', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_photos`
--

CREATE TABLE `tbl_photos` (
  `id` int(11) NOT NULL,
  `filename` varchar(255) NOT NULL,
  `filetype` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `userId` int(11) NOT NULL,
  `studyId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_photos`
--

INSERT INTO `tbl_photos` (`id`, `filename`, `filetype`, `url`, `userId`, `studyId`) VALUES
(5, 'test.png', 'png', 'https://v2.convertapi.com/d/un6hzd99141o602q0tgivn640e2amp83', 32, 71),
(6, 'Screenshot (39).png', 'png', 'https://v2.convertapi.com/d/6bnl81wdes3w8mfbz3a5qna5myeo9koe', 32, 71);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_profiles`
--

CREATE TABLE `tbl_profiles` (
  `id` int(11) NOT NULL,
  `profile` varchar(255) NOT NULL,
  `age` int(11) NOT NULL,
  `contact_no` varchar(11) NOT NULL,
  `gender` varchar(25) NOT NULL,
  `createdAt` varchar(75) NOT NULL,
  `userId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_profiles`
--

INSERT INTO `tbl_profiles` (`id`, `profile`, `age`, `contact_no`, `gender`, `createdAt`, `userId`) VALUES
(1, 'mahal.jpg', 22, '09557861231', 'female', '', 22),
(2, 'Screenshot (39).png', 21, '09758784764', 'male', '', 37);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_studies`
--

CREATE TABLE `tbl_studies` (
  `id` int(11) NOT NULL,
  `title` varchar(75) NOT NULL,
  `proponent` varchar(75) NOT NULL,
  `technology_type` varchar(25) NOT NULL,
  `contact_information` varchar(11) NOT NULL,
  `file` varchar(100) NOT NULL,
  `authors` varchar(255) NOT NULL,
  `created_at` varchar(50) NOT NULL,
  `status` varchar(15) NOT NULL,
  `bg_color` varchar(25) NOT NULL,
  `is_new_uploaded` tinyint(1) NOT NULL,
  `userId` int(11) NOT NULL,
  `has_log_submission` tinyint(1) NOT NULL,
  `college` varchar(255) NOT NULL,
  `intellectual_property` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_studies`
--

INSERT INTO `tbl_studies` (`id`, `title`, `proponent`, `technology_type`, `contact_information`, `file`, `authors`, `created_at`, `status`, `bg_color`, `is_new_uploaded`, `userId`, `has_log_submission`, `college`, `intellectual_property`) VALUES
(61, 'Chap1', 'Julie Ann Abrea', 'chemical', '09089786775', 'Chapter I.docx', 'julie@gmail.com', 'February 18, 2023', 'Accept', 'a5ffc5', 0, 32, 1, 'COE', 'UM'),
(62, 'Chap2', 'Julie Ann Abrea', 'chemical', '09789768678', 'Layout1 (5).docx', 'jheselleabrea@gmail.com', 'February 25, 2023', 'Pending', 'ffa39e', 0, 31, 0, 'COE', 'Industrial'),
(71, 'transformer', 'test', 'chemical', '89797898798', 'Updated_CV_Richard (1).doc', 'julie@gmail.com', 'May 01, 2023', 'Pending', 'e3e5e6', 0, 32, 0, 'CAFES', 'Industrial');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_accounts`
--
ALTER TABLE `tbl_accounts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_codes`
--
ALTER TABLE `tbl_codes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_college`
--
ALTER TABLE `tbl_college`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_comments`
--
ALTER TABLE `tbl_comments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_documents`
--
ALTER TABLE `tbl_documents`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_document_types`
--
ALTER TABLE `tbl_document_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_log_submission`
--
ALTER TABLE `tbl_log_submission`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_photos`
--
ALTER TABLE `tbl_photos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_profiles`
--
ALTER TABLE `tbl_profiles`
  ADD PRIMARY KEY (`id`),
  ADD KEY `userId` (`userId`);

--
-- Indexes for table `tbl_studies`
--
ALTER TABLE `tbl_studies`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_accounts`
--
ALTER TABLE `tbl_accounts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `tbl_codes`
--
ALTER TABLE `tbl_codes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `tbl_college`
--
ALTER TABLE `tbl_college`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `tbl_comments`
--
ALTER TABLE `tbl_comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=159;

--
-- AUTO_INCREMENT for table `tbl_documents`
--
ALTER TABLE `tbl_documents`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- AUTO_INCREMENT for table `tbl_document_types`
--
ALTER TABLE `tbl_document_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_log_submission`
--
ALTER TABLE `tbl_log_submission`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT for table `tbl_photos`
--
ALTER TABLE `tbl_photos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tbl_profiles`
--
ALTER TABLE `tbl_profiles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_studies`
--
ALTER TABLE `tbl_studies`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=72;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_profiles`
--
ALTER TABLE `tbl_profiles`
  ADD CONSTRAINT `tbl_profiles_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `tbl_accounts` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
