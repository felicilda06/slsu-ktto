-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 03, 2022 at 11:59 AM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.0.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `slsu_kttodb`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_accounts`
--

CREATE TABLE `tbl_accounts` (
  `id` int(11) NOT NULL,
  `studentId` varchar(50) DEFAULT NULL,
  `email` varchar(50) NOT NULL,
  `name` varchar(75) NOT NULL,
  `password` varchar(255) NOT NULL,
  `usertype` varchar(20) NOT NULL,
  `technology_type` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_accounts`
--

INSERT INTO `tbl_accounts` (`id`, `studentId`, `email`, `name`, `password`, `usertype`, `technology_type`) VALUES
(22, '', 'juviecano10@gmail.com', 'Juvie Cano', 'dc107fd4d7a7cb25c3d39bcdbcf1b1f94086eccb', 'patent drafter', 'chemical'),
(26, '1610131', 'felicildarichard06@gmail.com', 'Richard', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', 'maker', ''),
(28, '', 'lindell@gmail.com', 'Lindell', 'cce7aa8d4b90d8032bbf21a475a17ee00ed3548f', 'patent drafter', 'non-chemical'),
(29, '', 'admin@gmail.com', 'Slsu-ktto', 'd033e22ae348aeb5660fc2140aec35850c4da997', 'admin', '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_codes`
--

CREATE TABLE `tbl_codes` (
  `id` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `code` int(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_codes`
--

INSERT INTO `tbl_codes` (`id`, `email`, `code`) VALUES
(15, 'juviecano10@gmail.com', 9061);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_comments`
--

CREATE TABLE `tbl_comments` (
  `id` int(11) NOT NULL,
  `comments` varchar(10000) NOT NULL,
  `maker_id` int(11) NOT NULL,
  `patent_id` int(11) NOT NULL,
  `sender` int(11) NOT NULL,
  `receiver` int(11) NOT NULL,
  `read` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_comments`
--

INSERT INTO `tbl_comments` (`id`, `comments`, `maker_id`, `patent_id`, `sender`, `receiver`, `read`) VALUES
(14, 'accepted', 18, 22, 22, 18, 0),
(15, 'This study is now submitted to IPOPHIL.', 21, 29, 29, 21, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_documents`
--

CREATE TABLE `tbl_documents` (
  `id` int(11) NOT NULL,
  `formality_result` varchar(255) NOT NULL,
  `acknowledgement_receipt` varchar(255) NOT NULL,
  `notice_of_withdrawal` varchar(255) NOT NULL,
  `notice_of_publication` varchar(255) NOT NULL,
  `certification` varchar(255) NOT NULL,
  `log_submission_status` varchar(255) NOT NULL,
  `response` varchar(255) NOT NULL,
  `patent_id` int(11) NOT NULL,
  `maker_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_documents`
--

INSERT INTO `tbl_documents` (`id`, `formality_result`, `acknowledgement_receipt`, `notice_of_withdrawal`, `notice_of_publication`, `certification`, `log_submission_status`, `response`, `patent_id`, `maker_id`) VALUES
(18, 'formality_result_18_pexels-mike-b-170811 (1).jpg', 'acknowledgement_receipt_18_Screenshot (1) (3).png', 'notice_of_withdrawal_18_Screenshot (1) (3).png', 'notice_of_publication_18_ebfa5668bd2b6a4a2d706a89d56d9751.png', 'certification_18_Screenshot (1).png', 'log_submission_status_18_Screenshot (5).png', 'response_18_Screenshot (2).png', 22, 18),
(19, 'formality_result_21_Screenshot (2).png', 'acknowledgement_receipt_21_Screenshot (4).png', '', '', '', '', '', 29, 21);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_document_types`
--

CREATE TABLE `tbl_document_types` (
  `id` int(11) NOT NULL,
  `label` varchar(100) NOT NULL,
  `value` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_document_types`
--

INSERT INTO `tbl_document_types` (`id`, `label`, `value`) VALUES
(1, 'Drafted Documents', 'drafted documents'),
(2, 'Formality Exam Result', 'formality exam result');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_log_submission`
--

CREATE TABLE `tbl_log_submission` (
  `id` int(11) NOT NULL,
  `application_no` varchar(50) NOT NULL,
  `title` varchar(75) NOT NULL,
  `creator` varchar(75) NOT NULL,
  `ip_type` varchar(10) NOT NULL,
  `college` varchar(75) NOT NULL,
  `dragon_pay` varchar(75) NOT NULL,
  `application_date` varchar(50) NOT NULL,
  `agent` varchar(50) NOT NULL,
  `drafter` varchar(75) NOT NULL,
  `document_where_about` varchar(75) NOT NULL,
  `publication_date` varchar(50) NOT NULL,
  `publication_vol` varchar(10) NOT NULL,
  `publication_no` varchar(10) NOT NULL,
  `registration_date` varchar(50) NOT NULL,
  `registration_date_vol` varchar(10) NOT NULL,
  `registration_date_no` varchar(10) NOT NULL,
  `examiner` varchar(50) NOT NULL,
  `status` varchar(100) NOT NULL,
  `remark_1` varchar(100) NOT NULL,
  `remark_2` varchar(100) NOT NULL,
  `office_remark` varchar(100) NOT NULL,
  `action_step_1` varchar(75) NOT NULL,
  `action_step_2` varchar(75) NOT NULL,
  `certificate_office` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_log_submission`
--

INSERT INTO `tbl_log_submission` (`id`, `application_no`, `title`, `creator`, `ip_type`, `college`, `dragon_pay`, `application_date`, `agent`, `drafter`, `document_where_about`, `publication_date`, `publication_vol`, `publication_no`, `registration_date`, `registration_date_vol`, `registration_date_no`, `examiner`, `status`, `remark_1`, `remark_2`, `office_remark`, `action_step_1`, `action_step_2`, `certificate_office`) VALUES
(17, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'Registered', '', '', '', '', '', ''),
(19, '123131231-23', 'Test', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'Under Formality Examination', '', '', '', '', '', ''),
(20, '7897978987-2', 'Test', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'Forfeited', '', '', '', '', '', ''),
(21, '567567567-2', 'Test', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'Published', '', '', '', '', '', ''),
(22, '13123123-23', 'Test', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'Registered', '', '', '', '', '', ''),
(23, '12312312', 'Test', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'Forfeited', '', '', '', '', '', ''),
(24, '12312313-2', 'Test', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'Under Formality Examination', '', '', '', '', '', ''),
(25, '123123123', 'Test', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'Published', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_studies`
--

CREATE TABLE `tbl_studies` (
  `id` int(11) NOT NULL,
  `title` varchar(75) NOT NULL,
  `proponent` varchar(75) NOT NULL,
  `technology_type` varchar(25) NOT NULL,
  `contact_information` varchar(11) NOT NULL,
  `file` varchar(100) NOT NULL,
  `authors` varchar(255) NOT NULL,
  `created_at` varchar(50) NOT NULL,
  `status` varchar(15) NOT NULL,
  `bg_color` varchar(25) NOT NULL,
  `is_new_uploaded` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_studies`
--

INSERT INTO `tbl_studies` (`id`, `title`, `proponent`, `technology_type`, `contact_information`, `file`, `authors`, `created_at`, `status`, `bg_color`, `is_new_uploaded`) VALUES
(18, 'Test', 'test', 'chemical', '09456456456', 'Screenshot (1) (3).png', 'felicildarichard06@gmail.com', 'November 19, 2022', 'Accept', 'a5ffc5', 1),
(19, 'Biology', 'test', 'non-chemical', '08907897686', 'pexels-mike-b-170811 (2).jpg', 'yen@gmail.com', 'November 19, 2022', 'Accept', 'a5ffc5', 0),
(21, 'Test 31', 'test 3', 'non-chemical', '09808908908', 'Screenshot (2).png', 'felicildarichard06@gmail.com', 'November 19, 2022', 'Accept', 'a5ffc5', 1),
(22, 'Test 5', 'test 5', 'non-chemical', '09786875675', 'pexels-mike-b-170811 (2).jpg', 'felicildarichard06@gmail.com', 'November 19, 2022', 'Pending', 'e3e5e6', 0),
(23, 'test 6', 'test 6', 'chemical', '08797878978', 'Screenshot (1).png', 'felicildarichard06@gmail.com', 'November 22, 2022', 'Pending', 'e3e5e6', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_accounts`
--
ALTER TABLE `tbl_accounts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_codes`
--
ALTER TABLE `tbl_codes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_comments`
--
ALTER TABLE `tbl_comments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_documents`
--
ALTER TABLE `tbl_documents`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_document_types`
--
ALTER TABLE `tbl_document_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_log_submission`
--
ALTER TABLE `tbl_log_submission`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_studies`
--
ALTER TABLE `tbl_studies`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_accounts`
--
ALTER TABLE `tbl_accounts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `tbl_codes`
--
ALTER TABLE `tbl_codes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `tbl_comments`
--
ALTER TABLE `tbl_comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `tbl_documents`
--
ALTER TABLE `tbl_documents`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `tbl_document_types`
--
ALTER TABLE `tbl_document_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_log_submission`
--
ALTER TABLE `tbl_log_submission`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `tbl_studies`
--
ALTER TABLE `tbl_studies`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
